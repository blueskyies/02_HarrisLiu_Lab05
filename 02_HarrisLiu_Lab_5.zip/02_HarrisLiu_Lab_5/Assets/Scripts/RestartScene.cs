﻿using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class RestartScene : MonoBehaviour
{
    public string nextSceneName;

    void Start()
    {
        Button nextButton = GetComponent<Button>();
        nextButton.onClick.AddListener(ChangeScene);
    }

    void ChangeScene()
    {
        SceneManager.LoadScene(nextSceneName);
    }
}