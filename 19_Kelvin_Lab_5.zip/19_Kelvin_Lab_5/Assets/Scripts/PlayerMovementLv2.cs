﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class PlayerMovementLv2 : MonoBehaviour
{
    public float speed;
    public Rigidbody PlayerRigidbody;
    public int CoinCount;
    public Text CoinTxt;
    private bool canCollect = true;
    // Start is called before the first frame update
    void Start()
    {
        CoinCount = 0;
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        float moveHorizontal = Input.GetAxis("Horizontal");
        float moveVertical = Input.GetAxis("Vertical");
        Vector3 movement = new Vector3(moveHorizontal, 0, moveVertical);
        PlayerRigidbody.AddForce(movement * speed * Time.deltaTime);
    }

    private void Update()
    {
        if (CoinCount == 4)
        {
            SceneManager.LoadScene("GameWin");
        }
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.tag == "Hazard")
        {
            SceneManager.LoadScene("GameLose");
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag == "Coin" && canCollect)
        {

            canCollect = false;
            Destroy(other.gameObject);
            AddScore();
            StartCoroutine(Reset());
        }
    }
    public void AddScore()
    {
        CoinCount++;
        CoinTxt.text = "Coins Collected : " + CoinCount;
    }


    IEnumerator Reset()
    {
        yield return new WaitForSeconds(0.5f);
        canCollect = true;
    }

}